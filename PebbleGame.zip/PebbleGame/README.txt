The test files are in the tests folder.
The txt file called "test.txt" is used by one of the unit tests.
JUnit 4.13.2 was used to make the tests.