
package threadingassignment;

/**
 *
 * @author Artur Kapitanczyk and Jason Gurung
 */


// enums for the colours of the bag.
public enum Colour {
    WHITE, BLACK
}
