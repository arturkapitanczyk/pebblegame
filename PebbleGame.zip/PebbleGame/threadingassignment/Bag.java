package threadingassignment;


        import java.util.ArrayList;
        import java.util.Random;
        import threadingassignment.Colour;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Artur Kapitanczyk and Jason Gurung
 */


public class Bag {
    private volatile ArrayList<Integer> pebbles;
    private Colour colour;
    private String id;
    private Bag linkedBag;
    private PebbleGame game;
    public Bag(String id, Colour colour, String[] data, PebbleGame game){
        this.id = id;
        this.colour = colour;
        this.game = game;
        this.pebbles = new ArrayList<Integer>();

        for (int i = 0;i < data.length;i++)
            this.pebbles.add(Integer.parseInt(data[i]));

    }



    /**
     * @return the pebble that is removed from the bag.
     * The method returns a random pebble when a player draws from the bag and removes it from the bag.
     */
    public synchronized int popRandom(){
        int temp = 0;
        int intRandom = 0;
        try {
            Random rand = new Random();
            if (this.pebbles.size() == 1){
                intRandom = 0;
            }
            else{
                intRandom = rand.nextInt(this.pebbles.size());
            }
            temp = this.pebbles.get(intRandom);
            this.pebbles.remove(intRandom);
            return temp;
        }
        catch (Exception ex){
            return temp;
        }
    }

    // add a pebble to the bag.
    public void addPebble(int weight){
        try{
            this.pebbles.add(weight);

        } catch (Exception ex) {
            this.pebbles.add(1);
        }
    }

    // link a bag to a bag.
    public void linkToBag(Bag linkedBag){
        this.linkedBag = linkedBag;
    }

    // gets the list with the pebbles' weight values and returns the list.
    public ArrayList<Integer> getPebbles(){
        return this.pebbles;
    }

    // get ID of the bag and returns it.
    public String getID(){
        return this.id;
    }

    // gets the bag that is linked to the bag and returns the linked bag.
    public Bag getLinkedBag(){
        return this.linkedBag;
    }

    // fill bag with a list of pebbles' weight values.
    public void fillBag(ArrayList<Integer> pebbles){
        this.pebbles = pebbles;
    }

    // clears the bag.
    public void clearBag(){
        this.pebbles = new ArrayList<Integer>();
    }
}






