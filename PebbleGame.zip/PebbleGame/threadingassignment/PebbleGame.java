package threadingassignment;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * The type Pebble game.
 *
 * @author Artur Kapitanczyk and Jason Gurung
 */
public class PebbleGame {

    private ArrayList<Player> players = new ArrayList<Player>();
    private ArrayList<String> namesOfBagFiles = new ArrayList<String>();
    private volatile ArrayList<Bag> bags = new ArrayList<Bag>();
    private volatile static boolean gameIsOver = false;
    private int numberOfPlayers = 0;

    /**
     * Nested class that extends Thread.
     *The class is instantiated once for every player in the game.
     *
     */
    public class Player extends Thread{
        private String playerNumber;
        private volatile ArrayList<Integer> hand;
        private volatile Bag lastBagDrawnFrom;
        public Player(String nameOfFile) throws FileNotFoundException, IOException{
            this.playerNumber = nameOfFile;
            this.hand = new ArrayList<Integer>();
        }

        @Override
        public void run() {
            turn();
        }
        public void turn(){
            while (!PebbleGame.isGameOver()) {
                Random rand = new Random();
                int intRandom = 0;
                if (hand.size() == 0) {
                    intRandom = rand.nextInt(3);

                    for (int y = 0; y < 10; y++) {
                        this.lastBagDrawnFrom = bags.get(intRandom);
                        this.addToHand(bags.get(intRandom).popRandom());
                    }

                } else {
                    int sum = 0;
                    for (int i = 0; i < this.hand.size(); i++)
                        sum = sum + this.hand.get(i);


                    if (sum == 100) {
                        //code if a player wins
                        System.out.println("Player " + this.playerNumber + " has won!!!");
                        PebbleGame.endGame();
                    } else {
                        //normal turn

                        //first discard random pebble to bag linked with the bag
                        //last drawn from

                        //finding index in bags of the bag linked to last bag drawn from
                        int index = 0;
                        for (int i = 0; i < bags.size(); i++)
                            if (bags.get(i).equals(this.lastBagDrawnFrom.getLinkedBag()))
                                index = i;

                        //discarding action (with selecting random pebble weight from hand)
                        int indexOfPebbleToDiscard = rand.nextInt(hand.size());
                        int pebbleWeightDiscard = this.pop(indexOfPebbleToDiscard);
                        bags.get(index).addPebble(pebbleWeightDiscard);

                        savePlayerMove(this, false, pebbleWeightDiscard, bags.get(index));


                        //second draw a pebble from random bag
                        intRandom = rand.nextInt(3);

                        if (bags.get(intRandom).getPebbles().isEmpty()) {
                            bags.get(intRandom).fillBag(bags.get(intRandom).getLinkedBag().getPebbles());
                            bags.get(intRandom).getLinkedBag().clearBag();
                        }


                        this.lastBagDrawnFrom = bags.get(intRandom);
                        int pebbleWeightDraw = bags.get(intRandom).popRandom();
                        this.addToHand(pebbleWeightDraw);

                        savePlayerMove(this, true, pebbleWeightDraw, bags.get(intRandom));
                    }
                }


            }
        }

        /**
         * Pop int.
         *
         * @param index the index of the pebble that is removed from player hand.
         * @return the pebble that is removed from player hand.
         */
        public synchronized int pop(int index){
            int temp = this.hand.get(index);
            this.hand.remove(index);
            return temp;
        }


        /**
         * Set player number.
         *
         * @param playerNumber the player number
         */
        public void setPlayerNumber(String playerNumber){
            this.playerNumber = playerNumber;
        }

        /**
         * Get player number string.
         *
         * @return the player number string
         */
        public String getPlayerNumber(){
            return this.playerNumber;
        }

        /**
         * Add the pebble to hand.
         *
         * @param weight the weight value of the pebble.
         */
        public void addToHand(int weight){
            this.hand.add(weight);
        }
    }


    /**
     * Is game over boolean.
     *
     * @return the boolean
     */
    public static boolean isGameOver(){
        return gameIsOver;
    }

    /**
     * Sets gameIsOver variable to true.
     */
    public static void endGame(){
        gameIsOver = true;
    }

    /**
     * Read user input string.
     *
     * @return the string entered by user.
     */
    public String readUserInput(){
        Scanner myObj = new Scanner(System.in);
        String value = myObj.nextLine();

        return value;
    }


    /**
     * Read file string [ ].
     *
     * @param pathToFile the path to file
     * @return the string [ ] string array of objects containing the pebbles' weight values.
     * @throws FileNotFoundException the file not found exception
     * @throws IOException           the io exception
     */
    public String[] readFile(String pathToFile) throws FileNotFoundException, IOException{
        BufferedReader fileReader = new BufferedReader(new FileReader(pathToFile));
        String row;
        String[] data = {};
        while ((row = fileReader.readLine()) != null)
        {
            // Splits the string where there are whitespaces or commas.
            data = row.split("[\\s,]+");
        }
        fileReader.close();
        //checking validity of data
        for (int i = 0;i < data.length;i++){
            int number = Integer.parseInt(data[i]);
            if (number < 0){
                System.out.println("Negative value in input file, change and restart the program.");
                System.exit(1);
            }
        }
        if (data.length < 11 * this.numberOfPlayers){
            System.out.println("Too few values in input file, change and restart the program.");
            System.exit(1);
        }
        return data;
    }


    /**
     * Save player move.
     *
     * @param player      the player who has made the move.
     * @param drawDiscard boolean value deciding whether the player will draw or discard a pebble.
     * @param weight      the weight value of the pebble drawn my player.
     * @param bag         the bag which the pebble is drawn from or discard to.
     */
    public void savePlayerMove(Player player, Boolean drawDiscard, int weight, Bag bag){
        try {
            File file = new File("player" + player.getPlayerNumber()+ "_output.txt");
            if (file.createNewFile()){
                //file already exists
            }

            if (drawDiscard)
            {
                // writing details (drawn/discarded value and associated bag) about player move to a file.
                PrintWriter out = new PrintWriter(new FileWriter("player" + player.getPlayerNumber()+ "_output.txt", true));
                out.write("player" + player.getPlayerNumber() + " has drawn a " + weight + " from bag " + bag.getID());
                out.write("\n");
                out.flush();
                out.close();
            }
            else
            {
                PrintWriter out = new PrintWriter(new FileWriter("player" + player.getPlayerNumber()+ "_output.txt", true));
                out.write("player" + player.getPlayerNumber() + " has discarded a " + weight + " to bag " + bag.getID());
                out.write("\n");
                out.flush();
                out.close();
            }
        }catch(Exception ex){}
    }
    /**
     * The entry point of application.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) throws IOException {

        PebbleGame pebblegame = new PebbleGame();



        String gameStartMessage = "Welcome to the PebbleGame";
        gameStartMessage += "\r\n" + "You will be asked to enter the number of "
                + "players.";
        gameStartMessage += "\r\n" + "and then for the location of three files "
                + "in turn containing comma separated integer values for the "
                + "pebble weights.";
        gameStartMessage += "\r\n" + "The integer values must be strictly "
                + "positive";
        gameStartMessage += "\r\n" + "The game will then be simulated, and "
                + "output written to the files in this directory";
        gameStartMessage += "\r\n";
        gameStartMessage += "\r\n" + "Please enter the number of players:";

        System.out.println(gameStartMessage);

        boolean correctInput = false;


        // Only allowing positive number of players
        while (!correctInput){
            String input = pebblegame.readUserInput();
            pebblegame.numberOfPlayers = Integer.parseInt(input);
            if (pebblegame.numberOfPlayers >= 0)
                correctInput = true;
            else{
                String reEnterMessage = "Invalid number of players, please enter "
                        + "a valid number";
                System.out.println(reEnterMessage);
            }

        }

        // asking user to enter the locations of the bags.
        for (int i = 0;i < 3;i++){
            String fileInputString = "Please enter the location of bag number " + i + " to load:";
            System.out.println(fileInputString);
            // read user input.
            String tempFileName = pebblegame.readUserInput();
            pebblegame.namesOfBagFiles.add(tempFileName);

        }

        for (int i = 0;i < pebblegame.numberOfPlayers;i++){

            pebblegame.players.add(pebblegame.new Player(String.valueOf(i)));


        }

        // creating the black bags.
        try {
            pebblegame.bags.add(new Bag( "X", Colour.BLACK, pebblegame.readFile(pebblegame.namesOfBagFiles.get(0)),
                    pebblegame));
            pebblegame.bags.add(new Bag( "Y", Colour.BLACK, pebblegame.readFile(pebblegame.namesOfBagFiles.get(1)),
                    pebblegame));
            pebblegame.bags.add(new Bag( "Z", Colour.BLACK, pebblegame.readFile(pebblegame.namesOfBagFiles.get(2)),
                    pebblegame));

            File whitebagA = new File("whitebagA.csv");
            File whitebagB = new File("whitebagB.csv");
            File whitebagC = new File("whitebagC.csv");

            // creating the white bags
            pebblegame.bags.add(new Bag( "A", Colour.WHITE, new String[]{}, pebblegame));
            pebblegame.bags.add(new Bag( "B", Colour.WHITE, new String[]{}, pebblegame));
            pebblegame.bags.add(new Bag( "C", Colour.WHITE, new String[]{}, pebblegame));

            // linking the black bags to the white bags.
            for (int i = 0;i < 3;i++)
                pebblegame.bags.get(i).linkToBag(pebblegame.bags.get(i+3));

            for (int i = 3; i < 6;i++)
                pebblegame.bags.get(i).linkToBag(pebblegame.bags.get(i-3));


        } catch (IOException ex) {
            Logger.getLogger(PebbleGame.class.getName()).log(Level.SEVERE, null, ex);
        }

        // starting the threads for each player.

        for (int i = 0;i < pebblegame.numberOfPlayers;i++){
            pebblegame.players.get(i).start();
        }





    }

}
