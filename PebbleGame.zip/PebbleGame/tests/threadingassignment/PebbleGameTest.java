package threadingassignment;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.*;

public class PebbleGameTest {

    PebbleGame pebbleGame = new PebbleGame();
    Bag testBag = new Bag("X", Colour.BLACK, new String[]{"12"}, new PebbleGame());

    /**
     * Method used for testing the savePlayerMove method
     */
    public String readFile(String pathToFile) throws FileNotFoundException, IOException{
        BufferedReader fileReader = new BufferedReader(new FileReader(pathToFile));
        String row;
        String lastLine = "";
        while ((row = fileReader.readLine()) != null)
        {
            lastLine = row;
        }
        fileReader.close();
        return lastLine;
    }

    /**
     * The method tests the isGameOver method by comparing the output of the
     * method when applied to a pre-set new PebbleGame object to the expected
     * value of false
     */
    @Test
    public void isGameOver() {
        assertFalse(PebbleGame.isGameOver());
    }

    /**
     * The method tests the endGame method by checking if the value of
     * isGameOver changes to true from a new pebblegame where it is set to false
     */
    @Test
    public void endGame() {
        PebbleGame.endGame();
        assertTrue(PebbleGame.isGameOver());
    }

    /**
     * The method tests the readFile method by comparing the output of the
     * method when applied to a pre-set file to the expected values in the file
     */
    @Test
    public void readFile() throws IOException {
        String[] testString = pebbleGame.readFile("test.txt");
        assertArrayEquals(new String[]{"1", "2", "3", "4", "5"}, testString);
    }

    /**
     * The method tests the savePlayerMove method reading the saved sample text
     * written to the file and comparing it to the expected value
     */
    @Test
    public void savePlayerMove() throws IOException {
        PebbleGame.Player player = pebbleGame.new Player("-15");

        pebbleGame.savePlayerMove(player, false, 18, testBag);
        String line = readFile("player" + player.getPlayerNumber() + "_output.txt");
        assertEquals("player-15 has discarded a 18 to bag X", line);
    }


}