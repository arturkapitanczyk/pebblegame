package threadingassignment;

import org.junit.Test;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class BagTest {
    Bag emptyBag = new Bag("X", Colour.BLACK, new String[]{}, new PebbleGame());
    Bag filledBag = new Bag("A", Colour.BLACK, new String[]{"1", "2", "3", "4",
            "5"}, new PebbleGame());

    /**
     * The method tests the popRandom method by checking if the usage of the
     * method on a bag object shrinks the size of its pebble ArrayList by 1
     */
    @Test
    public void popRandom() {
        filledBag.popRandom();
        assertEquals(4, filledBag.getPebbles().size());
    }

    /**
     * The method tests the addPebble method by checking if adding a value to
     * an empty ArrayList creates the same object of ArrayLists as using the
     * addPebble method on a empty bag
     */
    @Test
    public void addPebble() {
        emptyBag.addPebble(12);
        ArrayList<Integer> testBag = new ArrayList<Integer>();
        testBag.add(12);
        assertEquals(testBag, emptyBag.getPebbles());
    }

    /**
     * The method tests the linkToBag method by using the getLinkedBag method
     * to see if the bag points to the correct object
     */
    @Test
    public void linkToBag() {
        emptyBag.linkToBag(filledBag);
        assertEquals(filledBag, emptyBag.getLinkedBag());
    }

    /**
     * The method tests the getPebbles method by comparing the output of the
     * method when applied to a pre-set object to the expected value
     */
    @Test
    public void getPebbles() {
        ArrayList<Integer> testBag = new ArrayList<Integer>();
        testBag.add(1);
        testBag.add(2);
        testBag.add(3);
        testBag.add(4);
        testBag.add(5);
        assertEquals(testBag, filledBag.getPebbles());
    }
    /**
     * The method tests the getID method by comparing the output of the
     * method when applied to a pre-set object to the expected value
     */
    @Test
    public void getID() {
        assertEquals("X", emptyBag.getID());
    }

    /**
     * The method tests the getLinkedBag method by using the linkToBag method
     * to first establish a connection and then checking if the connection
     * is appropriately displayed
     */
    @Test
    public void getLinkedBag() {
        emptyBag.linkToBag(filledBag);
        assertEquals(filledBag, emptyBag.getLinkedBag());
    }

    /**
     * The method tests the getID method by comparing the output of the
     * method when applied to a pre-set object to the expected value
     */
    @Test
    public void fillBag() {
        ArrayList<Integer> testBag = new ArrayList<Integer>();
        testBag.add(1);
        testBag.add(2);
        testBag.add(3);
        testBag.add(4);
        testBag.add(5);
        emptyBag.fillBag(filledBag.getPebbles());
        assertEquals(testBag, emptyBag.getPebbles());
    }
}